package desserialisation;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

 
public class GameObject {
    
    private String points;
    private String timeout;    
    private String type;


    public GameObject() {
    }

    public GameObject(String points, String timeout, String type) {
        super();
        this.points = points;
        this.timeout = timeout;
        this.type = type;
    }


    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }


    public String getTimeout() {
        return timeout;
    }

    public void setTimeout(String timeout) {
        this.timeout = timeout;
    }
    


    @XmlAttribute
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
    @Override
    public String toString(){
        return "(points = " + points + 
                ") (timout = " + timeout + ") (type = " + type.toString() + ")";
    }


}