package desserialisation;

import java.util.List;  
  
import javax.xml.bind.annotation.XmlAttribute;  
import javax.xml.bind.annotation.XmlElement;  
import javax.xml.bind.annotation.XmlRootElement;  

/**
 *
 * @author amh
 */



  
@XmlRootElement  
public class Mode {
    
    private List<GameObject> gameObjects;
    private String name, start_score, end_score, rounds;

    public Mode() {
    }

    public Mode(String name, String start_score, String end_score, String rounds, List<GameObject> gameObjects) {
        super();
        this.name = name;
        this.rounds = rounds;
        this.start_score = start_score;
        this.end_score = end_score;
        this.gameObjects = gameObjects;
    }


    @XmlElement
    public String getName() {
        return name;
    }



    public void setName(String name) {
        this.name = name;
    }

    @XmlElement
    public String getStart_score() {
        return start_score;
    }

    public void setStart_score(String start_score) {
        this.start_score = start_score;
    }

    @XmlElement
    public String getEnd_score() {
        return end_score;
    }

    public void setEnd_score(String end_score) {
        this.end_score = end_score;
    }

    @XmlElement
    public String getRounds() {
        return rounds;
    }

    
    public void setRounds(String rounds) {
        this.rounds = rounds;
    }

    @XmlElement
    public List<GameObject> getGameObjects() {
        return gameObjects;
    }

    public void setGameObjects(List<GameObject> gameObjects) {
        this.gameObjects = gameObjects;
    }

 
    

    @Override
    public String toString(){
        String result = 
                "(name = " + name + ") \n" +
                "(rounds = " + rounds + ") \n" +
                "(start_core " + start_score + ") \n" +
                "(end_score  " + end_score + ") \n"  ;     
        
        for (GameObject gO : gameObjects){
            result += gO.toString();
        }
               
        return result;
    }    


}
