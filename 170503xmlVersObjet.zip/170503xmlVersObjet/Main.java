package desserialisation;

import java.io.File;  
import java.util.List;  
  
import javax.xml.bind.JAXBContext;  
import javax.xml.bind.JAXBException;  
import javax.xml.bind.Unmarshaller;  
   
public class Main {  
    public static void main(String[] args) {  
    
     try {  
   
        File file = new File("mode.xml");  
        JAXBContext jaxbContext = JAXBContext.newInstance(Mode.class);  
   
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
        Mode mode = (Mode)jaxbUnmarshaller.unmarshal(file);          

        System.out.println(mode);
        
      } catch (JAXBException e) {  
        e.printStackTrace();  
      }
   
    }  
}
